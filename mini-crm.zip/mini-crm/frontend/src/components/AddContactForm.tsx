import { useForm } from '@mantine/form';
import { TextInput, Button, Grid, Title, Box, Alert } from '@mantine/core';
import { IconUserPlus, IconAlertCircle } from '@tabler/icons-react';
import { useState } from 'react';
import config from '../config';

interface ContactForm {
  nom: string;
  email: string;
  telephone: string;
  entreprise: string;
}

interface AddContactFormProps {
  onContactAdded: () => void;
}

const formatPhoneNumber = (value: string): string => {
  // Supprimer tout ce qui n'est pas un chiffre
  const numbers = value.replace(/\D/g, '').slice(0, 10);
  
  // Formatter par groupes de deux chiffres avec double espace
  return numbers.replace(/(\d{2})(?=\d)/g, '$1  ');
};

const validatePhoneNumber = (value: string): string | null => {
  if (!value) return null; // Le champ est optionnel

  // Supprimer les espaces pour la validation
  const numbers = value.replace(/\s/g, '');
  
  // Vérifier si ce sont uniquement des chiffres
  if (!/^\d+$/.test(numbers)) {
    return 'Veuillez saisir uniquement des chiffres';
  }

  // Vérifier la longueur
  if (numbers.length !== 10) {
    return 'Le numéro doit contenir exactement 10 chiffres';
  }

  // Vérifier le format français (commence par 0 suivi d'un chiffre entre 1 et 9)
  if (!/^0[1-9]/.test(numbers)) {
    return 'Le numéro doit commencer par 0 suivi d\'un chiffre entre 1 et 9';
  }

  return null;
};

export function AddContactForm({ onContactAdded }: AddContactFormProps) {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [phoneInputValue, setPhoneInputValue] = useState('');
  const [phoneError, setPhoneError] = useState<string | null>(null);

  const form = useForm<ContactForm>({
    initialValues: {
      nom: '',
      email: '',
      telephone: '',
      entreprise: '',
    },
    validate: {
      email: (value) => (/^\S+@\S+$/.test(value) ? null : 'Email invalide'),
      nom: (value) => (value.length < 2 ? 'Le nom doit contenir au moins 2 caractères' : null),
      telephone: validatePhoneNumber,
    },
  });

  const handleSubmit = async (values: ContactForm) => {
    try {
      setLoading(true);
      setError(null);

      // Nettoyer le numéro de téléphone (enlever les espaces)
      const cleanedValues = {
        ...values,
        telephone: values.telephone.replace(/\s/g, ''),
      };

      const response = await fetch(`${config.apiUrl}/contacts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(cleanedValues),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Erreur lors de l\'ajout du contact');
      }

      const data = await response.json();
      console.log('Contact ajouté avec succès:', data);
      
      form.reset();
      setPhoneInputValue('');
      setPhoneError(null);
      onContactAdded();
    } catch (err) {
      console.error('Erreur détaillée:', err);
      if (err instanceof Error) {
        if (err.message.includes('Failed to fetch') || err.message.includes('Network')) {
          setError('Erreur de connexion au serveur. Vérifiez que le backend est bien démarré.');
        } else {
          setError(err.message);
        }
      } else {
        setError('Une erreur inattendue est survenue');
      }
    } finally {
      setLoading(false);
    }
  };

  const handlePhoneInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.target.value;
    
    // Vérifier si l'entrée contient des caractères non autorisés
    if (/[^\d\s]/.test(input)) {
      setPhoneError('Veuillez saisir uniquement des chiffres');
      return;
    }
    
    // Formater le numéro
    const formatted = formatPhoneNumber(input);
    setPhoneInputValue(formatted);
    
    // Mettre à jour la valeur dans le formulaire
    const unformatted = formatted.replace(/\s/g, '');
    form.setFieldValue('telephone', unformatted);
    
    // Valider le format
    const validationError = validatePhoneNumber(unformatted);
    setPhoneError(validationError);
  };

  return (
    <Box>
      <Title order={2} mb="xl" sx={(theme) => ({
        color: theme.colors.brown[7],
        fontSize: theme.fontSizes.xl,
        fontWeight: 600,
      })}>
        Nouveau Contact
      </Title>

      {error && (
        <Alert 
          icon={<IconAlertCircle size={16} />}
          title="Erreur"
          color="red"
          mb="lg"
          variant="light"
          onClose={() => setError(null)}
          withCloseButton
        >
          {error}
        </Alert>
      )}

      <form onSubmit={form.onSubmit(handleSubmit)}>
        <Grid gutter="md">
          <Grid.Col span={{ base: 12, sm: 6 }}>
            <TextInput
              required
              label="Nom"
              placeholder="Jean Dupont"
              {...form.getInputProps('nom')}
            />
          </Grid.Col>

          <Grid.Col span={{ base: 12, sm: 6 }}>
            <TextInput
              required
              label="Email"
              placeholder="jean.dupont@email.com"
              {...form.getInputProps('email')}
            />
          </Grid.Col>

          <Grid.Col span={{ base: 12, sm: 6 }}>
            <TextInput
              label="Téléphone"
              placeholder="06  12  34  56  78"
              value={phoneInputValue}
              onChange={handlePhoneInput}
              error={phoneError}
              description="Format: 06  12  34  56  78"
              sx={(theme) => ({
                input: {
                  letterSpacing: '1px',
                  '&::placeholder': {
                    letterSpacing: 'normal',
                  },
                },
              })}
            />
          </Grid.Col>

          <Grid.Col span={{ base: 12, sm: 6 }}>
            <TextInput
              label="Entreprise"
              placeholder="Entreprise SAS"
              {...form.getInputProps('entreprise')}
            />
          </Grid.Col>

          <Grid.Col span={12}>
            <Button
              type="submit"
              fullWidth
              loading={loading}
              leftIcon={<IconUserPlus size={20} />}
              sx={(theme) => ({
                backgroundColor: theme.colors.brown[6],
                '&:hover': {
                  backgroundColor: theme.colors.brown[7],
                },
                height: '42px',
              })}
            >
              {loading ? 'Ajout en cours...' : 'Ajouter le contact'}
            </Button>
          </Grid.Col>
        </Grid>
      </form>
    </Box>
  );
}