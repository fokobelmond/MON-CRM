import { useEffect, useState } from 'react';
import { Table, Button, Group, Text, Box, Title, Alert, Loader } from '@mantine/core';
import { IconTrash, IconAlertCircle } from '@tabler/icons-react';
import config from '../config';

interface Contact {
  id: number;
  nom: string;
  email: string;
  telephone: string;
  entreprise: string;
}

export function ContactList() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchContacts = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch(`${config.apiUrl}/contacts`);
      if (!response.ok) {
        throw new Error('Erreur lors de la récupération des contacts');
      }
      const data = await response.json();
      setContacts(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  };

  const deleteContact = async (id: number) => {
    try {
      const response = await fetch(`${config.apiUrl}/contacts/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error('Erreur lors de la suppression du contact');
      }
      setContacts(contacts.filter(contact => contact.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue');
    }
  };

  useEffect(() => {
    fetchContacts();
  }, []);

  if (loading) {
    return (
      <Box sx={{ textAlign: 'center', padding: '2rem' }}>
        <Loader size="md" />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert
        icon={<IconAlertCircle size={16} />}
        title="Erreur"
        color="red"
        variant="light"
      >
        {error}
      </Alert>
    );
  }

  if (contacts.length === 0) {
    return (
      <Text ta="center" fz="lg" c="dimmed" py="xl">
        Aucun contact pour le moment
      </Text>
    );
  }

  return (
    <Box>
      <Title order={2} mb="xl" sx={(theme) => ({
        color: theme.colors.brown[7],
        fontSize: theme.fontSizes.xl,
        fontWeight: 600,
      })}>
        Liste des Contacts
      </Title>

      <Box sx={(theme) => ({
        overflowX: 'auto',
        [theme.fn.smallerThan('sm')]: {
          marginLeft: -theme.spacing.md,
          marginRight: -theme.spacing.md,
        },
      })}>
        <Table striped highlightOnHover withTableBorder>
          <Table.Thead>
            <Table.Tr>
              <Table.Th>Nom</Table.Th>
              <Table.Th>Email</Table.Th>
              <Table.Th>Téléphone</Table.Th>
              <Table.Th>Entreprise</Table.Th>
              <Table.Th style={{ width: '100px' }}>Actions</Table.Th>
            </Table.Tr>
          </Table.Thead>
          <Table.Tbody>
            {contacts.map((contact) => (
              <Table.Tr key={contact.id}>
                <Table.Td>{contact.nom}</Table.Td>
                <Table.Td>{contact.email}</Table.Td>
                <Table.Td>{contact.telephone}</Table.Td>
                <Table.Td>{contact.entreprise}</Table.Td>
                <Table.Td>
                  <Group justify="center">
                    <Button
                      color="red"
                      size="xs"
                      variant="subtle"
                      onClick={() => deleteContact(contact.id)}
                    >
                      <IconTrash size={16} />
                    </Button>
                  </Group>
                </Table.Td>
              </Table.Tr>
            ))}
          </Table.Tbody>
        </Table>
      </Box>
    </Box>
  );
}