const config = {
  apiUrl: process.env.NODE_ENV === 'production'
    ? 'https://fokobelmond.pythonanywhere.com'  // URL de production
    : 'http://localhost:5000'  // URL de développement
};

export default config;