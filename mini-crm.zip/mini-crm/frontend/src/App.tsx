import { MantineProvider, Container, Title, Paper, Box } from '@mantine/core';
import { ContactList } from './components/ContactList';
import { AddContactForm } from './components/AddContactForm';
import { useState } from 'react';
import '@mantine/core/styles.css';

function App() {
  const [refreshKey, setRefreshKey] = useState(0);

  const handleContactAdded = () => {
    setRefreshKey(prev => prev + 1);
  };

  return (
    <MantineProvider
      theme={{
        colors: {
          brown: [
            '#FDFBF7', // Fond très clair
            '#F5EDE3', // Fond clair
            '#E6D5C1', // Bordures légères
            '#D4BBA0', // Éléments inactifs
            '#C1A182', // Texte secondaire
            '#AA8661', // Texte principal
            '#8B6B4A', // Boutons normaux
            '#6D5237', // Boutons hover
            '#503C26', // Texte important
            '#342718', // Accents foncés
          ],
          blue: [
            '#F5F9FF',
            '#E3EFFF',
            '#C1DBFF',
            '#9FC7FF',
            '#7DB3FF',
            '#5B9FFF',
            '#3D8BFF',
            '#1F77FF',
            '#0063FF',
            '#0052D6',
          ],
        },
        primaryColor: 'brown',
        fontFamily: 'Inter, sans-serif',
        components: {
          Button: {
            styles: (theme) => ({
              root: {
                backgroundColor: theme.colors.brown[6],
                color: theme.white,
                transition: 'all 0.2s ease',
                '&:hover': {
                  backgroundColor: theme.colors.brown[7],
                  transform: 'translateY(-1px)',
                },
              },
            }),
          },
          TextInput: {
            styles: (theme) => ({
              input: {
                borderColor: theme.colors.brown[2],
                transition: 'all 0.2s ease',
                '&:focus': {
                  borderColor: theme.colors.brown[6],
                  boxShadow: `0 0 0 2px ${theme.colors.brown[1]}`,
                },
              },
              label: {
                color: theme.colors.brown[7],
                fontWeight: 500,
                marginBottom: '4px',
              },
            }),
          },
        },
      }}
    >
      <Box
        sx={(theme) => ({
          minHeight: '100vh',
          background: theme.colors.brown[0],
          padding: theme.spacing.md,
        })}
      >
        <Container size={{ base: '100%', sm: '90%', md: '80%', lg: '70%' }} py="xl">
          <Title
            order={1}
            mb="xl"
            ta="center"
            sx={(theme) => ({
              color: theme.colors.brown[8],
              fontSize: theme.fontSizes.xl * 2,
              fontWeight: 700,
              letterSpacing: '-0.5px',
              [theme.fn.smallerThan('sm')]: {
                fontSize: theme.fontSizes.xl * 1.5,
              },
            })}
          >
            Mon Premier CRM
          </Title>

          <Paper
            shadow="sm"
            radius="md"
            p={{ base: 'md', sm: 'xl' }}
            mb="xl"
            sx={(theme) => ({
              backgroundColor: theme.white,
              borderTop: `3px solid ${theme.colors.brown[6]}`,
              transition: 'transform 0.2s ease',
            })}
          >
            <AddContactForm onContactAdded={handleContactAdded} />
          </Paper>

          <Paper
            shadow="sm"
            radius="md"
            p={{ base: 'md', sm: 'xl' }}
            sx={(theme) => ({
              backgroundColor: theme.white,
              borderTop: `3px solid ${theme.colors.blue[6]}`,
            })}
          >
            <ContactList key={refreshKey} />
          </Paper>
        </Container>
      </Box>
    </MantineProvider>
  );
}

export default App;